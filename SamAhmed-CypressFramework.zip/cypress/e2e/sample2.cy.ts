describe.skip('My First Test', function() {
    it('Does not do much!', function() {
      expect(true).to.equal(true)
    })
  })